#!/usr/bin/env bash
git branch --show-current